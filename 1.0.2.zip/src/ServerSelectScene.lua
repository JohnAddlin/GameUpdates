----------------------------------------------
--	@ 	选择服务器
----------------------------------------------

----------------------------------------------
--	@ 	服务器场景配置
----------------------------------------------
ServerSelectSceneConfig 	= 	{
	Fonts 			= 	{
		File 	 		= 	"fonts/msyh.ttf";
		Size 			= 	32;
	};
	Sprites 			= 	{
		Background 	= 	{"Login/load_backbg-hd.png", };
	};
	Buttons 			= 	{
		Common 		= 	{"Login/popup_button_01.png", 	1, 1, 	};
	};
	Positions 			= 	{
		ScrollView 		= 	cc.p(0, 0);
	};
	Servers 			= 	{
		{	"通用服务器", 	"192.168.3.196", 		8300, 	};
		{	"服务器 - 刘", 	"192.168.3.19", 		8300, 	};
		{ 	"服务器 - 赵", 	"192.168.3.2", 		8300, 	};
	};

	ViewSize 			= 	cc.size(600, 320);
	Column 			= 	3;
};

----------------------------------------------
--	@ 	服务器选择场景
----------------------------------------------
ServerSelectScene 	= 	class("ServerSelectScene");

----------------------------------------------
--	@ 	创建服务器选择场景
function ServerSelectScene.Create( ... )
	-- body
	local 	serverSelectScene 	= 	ServerSelectScene.new();
	serverSelectScene:Init();
	return serverSelectScene;
end

--	@ 	初始化 
function ServerSelectScene:Init( ... )
	-- body
	--	监听器
	self.Listener 	= 	nil;

	--	创建界面
	self:CreateUI();

	--	注册触摸回调 
	self.Widget:RegisterTouchCallback(function ( ... )
		-- body
		self.Widget:removeFromParent();
	end)
end

--	@ 	创建UI
function ServerSelectScene:CreateUI( ... )
	-- body
	local 	config 	= 	ServerSelectSceneConfig;
	local 	viewSize 	= 	cc.Director:getInstance():getVisibleSize();
	local 	center 	= 	cc.p(viewSize.width/2, 	viewSize.height/2);

	--	主控件
	self.Widget 	= 	ModalLayer.Create(cc.c4b(0, 0, 0, 128));

	--	背景
	self.Background 	= 	ccui.Scale9Sprite:create(config.Sprites.Background[1]);
	self.Background:setCapInsets(cc.rect(self.Background:getContentSize().width/2 - 200, 	self.Background:getContentSize().height/2 - 150, 	400,  300))
	self.Background:setPosition(center);
	self.Background:setContentSize(cc.size(config.ViewSize.width + 100, 	config.ViewSize.height + 50));
	self.Widget:addChild(self.Background);

	--	菜单
	self.Menu 		=	cc.Menu:create();
	self.Menu:setPosition(cc.p(0, 0));
	self.Widget:addChild(self.Menu);

	--	滚动列表视图
	local 	params 		= 	{
		Style 		= 	SCROLLVIEW_STYLE_VERTICAL;
		ViewSize 		= 	config.ViewSize;
	};
	self.ScrollView 		=	ScrollView.Create(params);
	self.ScrollView:GetWidget():setPosition(	cc.pAdd(center, 	config.Positions.ScrollView)	);
	self.Widget:addChild(self.ScrollView:GetWidget());

	--	显示服务器列表
	local 	serverNums 	= 	#config.Servers;
	for 	i 	= 	1, 	serverNums 	do

		local 	serverConfig 	= 	config.Servers[i];
		-- local 	serverButton 	= 	self:CreateMenuSpriteItem(config.Buttons.Common, 	cc.p(0, 0), 	function ( sender )
		-- 	-- body
		-- 	self:HandleServerButtonClicked(sender);
		-- end)

		-- --	服务器名称
		-- local 	serverName 	= 	ccui.Text:create(tostring(serverConfig[1]), config.Fonts.File, 	config.Fonts.Size);
		-- serverButton:addChild(serverName);

		-- --	服务器IP&端口
		-- serverButton.ServerConfig 	= 	serverConfig;

		if 	i % config.Column 	~= 	1 	then
			self.ScrollView:AddContent("button", 	
				{ 
					File 		= 	config.Buttons.Common[1], 		
					Extra 	= 	{	serverConfig[1], 	config.Fonts.File, 	config.Fonts.Size, 	};
					Callback	= 	function ( sender )
						-- body
						self:HandleButtonServerClicked(sender);
					end
				}, 	false);
		else
			self.ScrollView:AddContent("button", 	
				{ 
					File 		= 	config.Buttons.Common[1], 		
					Extra 	= 	{	serverConfig[1], 	config.Fonts.File, 	config.Fonts.Size, 	};
					Callback 	= 	function ( sender )
						-- body
						self:HandleButtonServerClicked(sender);
					end
				});
		end
	end
	self.ScrollView:Relayout();
end

--	@ 	创建按钮
function ServerSelectScene:CreateMenuSpriteItem( config, position, callback )
	-- body
	local 	normal 	= 	cc.Sprite:create();
	local 	selected 	= 	cc.Sprite:create();
	local 	disabled 	= 	cc.Sprite:create();

	local 	file 		= 	config[1];
	local 	row 		= 	config[2];
	local 	column 	= 	config[3];

	local 	frameList 	= 	ButtonTextureHelper.ParseButtonTexture(file, row, column);

	--	按钮最少一帧
	if 	#frameList 	== 	3 	then
		disabled:setSpriteFrame(frameList[BUTTON_DISABLED]);
	end

	if 	#frameList 	>= 	2 	then
		selected:setSpriteFrame(frameList[BUTTON_SELECTED]);
	end

	normal:setSpriteFrame(frameList[BUTTON_NORMAL]);

	local 	item 	= 	cc.MenuItemSprite:create(normal, selected, disabled);
	
	item:setPosition(position);
	item:registerScriptTapHandler(callback);

	self.Menu:addChild(item);

	return item;
end

--	@ 	选择服务器按钮回调
function ServerSelectScene:HandleButtonServerClicked( sender )
	-- body
	print("选择服务器"..tostring(sender));

	local 	label 			= 	sender:getChildByTag(1);
	
	if 	label 	then
		local 	serverName  	= 	label:getString(); 				print(tostring(serverName));
		local 	serverConfig 	= 	ServerSelectSceneConfig.Servers;

		for 	v 	in pairs(serverConfig) 	do
			if 	serverConfig[v][1] 	== 	serverName 	then
				SERVER_NAME 		= 	serverConfig[v][1];
				SERVER_IP 		= 	serverConfig[v][2];
				SERVER_PORT 		= 	serverConfig[v][3];

				if 	self.Listener 	then
					self.Listener();
				end

				break;
			end
		end
	end
end

--	@ 	注册服务器选择变更
function ServerSelectScene:RegisterServerChangedListener( callback )
	-- body
	self.Listener 	= 	callback;
end